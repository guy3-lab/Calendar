package model.calendar;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import controller.parse.PropertyType;
import model.enums.Location;
import model.enums.Status;
import model.enums.WeekDays;

/**
 * represents a Calendar object that contains a year, and a list of months and its days.
 * This implementation correctly handles multi-day events while maintaining compatibility.
 */
public class Calendar implements ICalendar {
  private final Map<LocalDate, List<IEvent>> calendar;
  private Map<LocalDateTime, List<IEvent>> series;

  /**
   * Creates a calendar object that takes in a year as an argument to account for leap years.
   */
  public Calendar() {
    this.calendar = new HashMap<LocalDate, List<IEvent>>();
    this.series = new HashMap<LocalDateTime, List<IEvent>>();
  }

  @Override
  public Event createEvent(String subject, LocalDateTime startTime, LocalDateTime endTime) {
    Event event;
    if (endTime == null) {
      event = new Event(subject, startTime);
    } else {
      checkEndTimeAfterStart(endTime, startTime);
      event = new Event.EventBuilder(subject, startTime).end(endTime).build();
    }
    addEventHelper(event, startTime);
    return event;
  }

  //adds the event to the calendar date
  protected void addEventHelper(Event event, LocalDateTime startTime) {
    LocalDate startDate = startTime.toLocalDate();
    LocalDate endDate = event.getEnd().toLocalDate();

    // Add event to all dates it spans
    LocalDate currentDate = startDate;
    while (!currentDate.isAfter(endDate)) {
      if (!calendar.containsKey(currentDate)) {
        calendar.put(currentDate, new ArrayList<IEvent>());
      }

      List<IEvent> events = calendar.get(currentDate);

      // Only check for duplicates on the start date to avoid multiple checks
      if (currentDate.equals(startDate)) {
        alreadyExistsInCalendar(events, event);
      }

      events.add(event);
      currentDate = currentDate.plusDays(1);
    }
  }

  //checks if there's an event with the same fields
  private void alreadyExistsInCalendar(List<IEvent> events, IEvent event) {
    for (IEvent e : events) {
      if (e != event && e.equals(event)) {
        throw new IllegalArgumentException("Event already exists");
      }
    }
  }

  @Override
  public void createSeriesTimes(String subject, LocalDateTime startTime, LocalDateTime endTime,
                                List<String> repeatDays, int times) {
    if (this.series.containsKey(startTime)) {
      throw new IllegalArgumentException("Series already exists at this startTime");
    }
    this.series.put(startTime, new ArrayList<IEvent>());
    LocalDateTime[][] weekdayRanges = createSeriesHelper(repeatDays, startTime, endTime);

    for (LocalDateTime[] day : weekdayRanges) {
      LocalDateTime start = day[0];
      LocalDateTime end = day[1];

      for (int t = 0; t < times; t++) {
        this.series.get(startTime).add(createEvent(subject, start, end));
        start = start.plusDays(7);
        if (end != null) {
          end = end.plusDays(7);
        }
      }
    }
  }

  @Override
  public void createSeriesUntil(String subject, LocalDateTime startTime, LocalDateTime endTime,
                                List<String> repeatDays, LocalDate until) {
    if (this.series.containsKey(startTime)) {
      throw new IllegalArgumentException("Series already exists at this startTime");
    }
    this.series.put(startTime, new ArrayList<IEvent>());
    LocalDateTime[][] weekdayRanges = createSeriesHelper(repeatDays, startTime, endTime);

    for (LocalDateTime[] day : weekdayRanges) {
      while (!day[0].toLocalDate().isAfter(until)) {
        this.series.get(startTime).add(createEvent(subject, day[0], day[1]));
        day[0] = day[0].plusDays(7);
        if (endTime == null) {
          day[1] = null;
        } else {
          day[1] = day[1].plusDays(7);
        }
      }
    }
  }

  //checks if the start time and end time are of the same day
  private void checkEventIsOneDay(LocalDateTime startDate, LocalDateTime endDate) {
    LocalDate start = startDate.toLocalDate();
    LocalDate end = endDate.toLocalDate();
    if (!start.equals(end)) {
      throw new IllegalArgumentException("Start date and end date must be the same");
    }
  }

  //Gets the repeated local dates that are stored in a 2d array
  private LocalDateTime[][] createSeriesHelper(List<String> repeatDays, LocalDateTime startTime,
                                               LocalDateTime endTime) {
    LocalDateTime[][] weekdayRanges = new LocalDateTime[repeatDays.size()][2];

    for (int i = 0; i < repeatDays.size(); i++) {
      int dayNum = WeekDays.getDay(repeatDays.get(i));
      // Check for invalid weekday abbreviation
      if (dayNum == -1) {
        throw new IllegalArgumentException("Invalid weekday abbreviation: " + repeatDays.get(i));
      }
      int currentDay = startTime.getDayOfWeek().getValue();

      int difference = (dayNum - currentDay + 7) % 7;

      weekdayRanges[i][0] = LocalDateTime.of(startTime.toLocalDate().plusDays(difference),
              startTime.toLocalTime());
      if (endTime == null) {
        weekdayRanges[i][1] = null;
      } else {
        checkEventIsOneDay(startTime, endTime);
        weekdayRanges[i][1] = LocalDateTime.of(endTime.toLocalDate().plusDays(difference),
                endTime.toLocalTime());
      }
    }
    return weekdayRanges;
  }

  @Override
  public void editEvent(PropertyType property, String subject, LocalDateTime startTime,
                        LocalDateTime endTime, String value) {
    List<IEvent> events = this.calendar.get(startTime.toLocalDate());
    for (IEvent e : events) {
      if (e.getSubject().equals(subject) && e.getStart().equals(startTime)
              && e.getEnd().equals(endTime)) {
        editEventHelper(e, property, value);
        alreadyExistsInCalendar(events, e);
        break;
      }
    }
  }

  //checks the property to be changed and edits the fields of the event accordingly
  private void editEventHelper(IEvent e, PropertyType property, String value) {
    switch (property) {
      case SUBJECT:
        e.setSubject(value);
        break;
      case START:
        setStartHelper(e, value);
        break;
      case END:
        setEndHelper(e, value);
        break;
      case DESCRIPTION:
        e.setDesc(value);
        break;
      case LOCATION:
        e.setLocation(Location.valueOf(value.toUpperCase()));
        break;
      case STATUS:
        e.setStatus(Status.valueOf(value.toUpperCase()));
        break;
      default: //will have no default because it can only take in specified property
    }
  }

  //helper to set event's start time to value
  private void setStartHelper(IEvent e, String value) {
    LocalDateTime start = LocalDateTime.parse(value);
    LocalDateTime original = e.getStart();

    //updates the end time as well
    if (start.isAfter(original)) {
      e.setEnd(e.getEnd().plusMinutes(ChronoUnit.MINUTES.between(original, start)));
    }

    //removes the event from the series
    if (this.series.containsKey(original)) {
      this.series.get(original).remove(e);
    }

    //removes from the calendar key to a new one
    removeAndAddToCalendar(original, e, start);
    e.setStart(start);
  }

  //Helper method to set the event's end time to value
  private void setEndHelper(IEvent e, String value) {
    LocalDateTime end = LocalDateTime.parse(value);
    checkEndTimeAfterStart(end, e.getStart());
    e.setEnd(end);
  }

  //removes an event from a current date to another date
  private void removeAndAddToCalendar(LocalDateTime original, IEvent e, LocalDateTime newDate) {
    LocalDate originalEndDate = e.getEnd().toLocalDate();

    LocalDate currentDate = original.toLocalDate();
    while (!currentDate.isAfter(originalEndDate)) {
      if (this.calendar.containsKey(currentDate)) {
        this.calendar.get(currentDate).remove(e);
        if (this.calendar.get(currentDate).isEmpty()) {
          this.calendar.remove(currentDate);
        }
      }
      currentDate = currentDate.plusDays(1);
    }

    LocalDate newStartDate = newDate.toLocalDate();

    if (!this.calendar.containsKey(newStartDate)) {
      this.calendar.put(newStartDate, new ArrayList<>());
    }
    this.calendar.get(newStartDate).add(e);
  }

  @Override
  public void editEvents(PropertyType property, String subject,
                         LocalDateTime startTime, String value) {
    for (Map.Entry<LocalDateTime, List<IEvent>> entry : series.entrySet()) {
      List<IEvent> events = entry.getValue();
      for (IEvent e : events) {
        if (e.getStart().equals(startTime) && e.getSubject().equals(subject)) {
          for (int i = events.size() - 1; i >= 0; i--) {
            IEvent event = events.get(i);
            if (!event.getStart().isBefore(startTime) && event.getSubject().equals(subject)) {
              editEventsHelper(event, property, entry.getKey(), startTime, value);
              // Only check for duplicates if the event is still on the same date
              if (this.calendar.get(event.getStart().toLocalDate()) != null) {
                alreadyExistsInCalendar(this.calendar.get(event.getStart().toLocalDate()), event);
              }
            }
          }
          break;
        }
      }
    }
  }

  @Override
  public void editSeries(PropertyType property, String subject,
                         LocalDateTime startTime, String value) {
    if (this.series.containsKey(startTime)) {
      List<IEvent> events = this.series.get(startTime);
      for (int i = events.size() - 1; i >= 0; i--) {
        IEvent e = events.get(i);
        if (e.getSubject().equals(subject)) {
          editEventsHelper(e, property, startTime, startTime, value);
          // Only check for duplicates if the event is still on the same date
          if (this.calendar.get(e.getStart().toLocalDate()) != null) {
            alreadyExistsInCalendar(this.calendar.get(e.getStart().toLocalDate()), e);
          }
        }
      }
      removeSeries(property, startTime);
    }
  }

  //switch case for series
  private void editEventsHelper(IEvent e, PropertyType property, LocalDateTime key,
                                LocalDateTime base, String value) {
    long between;
    switch (property) {
      case START:
        between = ChronoUnit.MINUTES.between(base, LocalDateTime.parse(value));
        setStarterEventsHelper(e, value, between, key);
        break;

      //checks for exception, and then goes to the helper method to mutate
      case END:
        between = ChronoUnit.MINUTES.between(base, LocalDateTime.parse(value));
        setEndEventsHelper(e, value, between);
        break;

      default:
        editEventHelper(e, property, value);
    }
  }

  //sets a series of events to a new start time and putting it into a new series
  private void setStarterEventsHelper(IEvent e, String value, long between, LocalDateTime key) {
    LocalDateTime start = LocalDateTime.parse(value);
    LocalDateTime newDate = e.getStart().plusMinutes(between);

    if (this.series.containsKey(key)) {
      this.series.get(key).remove(e);
    }

    // Check if target series already exists
    if (this.series.containsKey(start)) {
      // Check if any existing event in target series is from a different original series
      for (IEvent existingEvent : this.series.get(start)) {
        if (existingEvent.getSeriesKey() != null && !key.equals(existingEvent.getSeriesKey())) {
          throw new IllegalArgumentException("Cannot add event from different series. " +
                  "Target series contains events from series: " + existingEvent.getSeriesKey());
        }
      }
    } else {
      // Create new series if it doesn't exist
      this.series.put(start, new ArrayList<>());
    }
    this.series.get(start).add(e);

    removeAndAddToCalendar(e.getStart(), e, newDate);

    // Update the event times
    e.setStart(newDate);
    if (newDate.isAfter(start) && newDate.toLocalTime().isAfter(e.getEnd().toLocalTime())) {
      e.setEnd(e.getEnd().plusMinutes(between));
    } else {
      e.setEnd(LocalDateTime.of(newDate.toLocalDate(), e.getEnd().toLocalTime()));
    }
  }

  //sets a series of event's end times
  private void setEndEventsHelper(IEvent e, String value, long between) {
    LocalDateTime end = e.getEnd().plusMinutes(between);
    LocalTime endTime = LocalDateTime.parse(value).toLocalTime();

    //check exceptions
    checkEndTimeAfterStart(end, e.getStart());
    checkEventIsOneDay(e.getStart().plusMinutes(between), end);

    e.setEnd(LocalDateTime.of(e.getEnd().toLocalDate(), endTime));
  }

  //removes a series
  private void removeSeries(PropertyType property, LocalDateTime start) {
    if (property == PropertyType.START && this.series.get(start) != null
            && this.series.get(start).isEmpty()) {
      this.series.remove(start);
    }
  }

  //checks that the end time is not before the start time
  private void checkEndTimeAfterStart(LocalDateTime end, LocalDateTime start) {
    if (end.isBefore(start)) {
      throw new IllegalArgumentException("End time must be after start time");
    }
  }

  @Override
  public String printEvents(LocalDate day) {
    if (!this.calendar.containsKey(day) || this.calendar.get(day).isEmpty()) {
      return "No events on this day";
    }

    List<String> events = new ArrayList<>();
    List<IEvent> eventList = this.calendar.get(day);
    for (IEvent e : eventList) {
      events.add(printHelper(e));
    }
    return String.join("\n", events);
  }

  @Override
  public String printEventsInterval(LocalDateTime start, LocalDateTime end) {
    LocalDate day = start.toLocalDate();
    LocalDate endDay = end.toLocalDate();
    List<String> events = new ArrayList<>();
    while (!day.isAfter(endDay)) {
      if (this.calendar.containsKey(day)) {
        List<IEvent> eventList = this.calendar.get(day);
        for (IEvent e : eventList) {
          if (!e.getStart().isBefore(start)) {
            events.add(printHelper(e));
          }
        }
      }
      day = day.plusDays(1);
    }
    return String.join("\n", events);
  }

  //creates the string to return
  private String printHelper(IEvent e) {
    String event = "";
    event += e.getSubject() + ", " + "Start Time: " + e.getStart() + ", "
            + "End Time: " + e.getEnd() + ", " + "Location: " + e.getLocation();
    return event;
  }

  @Override
  public String showStatus(LocalDateTime queryTime) {
    LocalDate queryDate = queryTime.toLocalDate();

    if (!this.calendar.containsKey(queryDate)) {
      return "available";
    }

    List<IEvent> events = this.calendar.get(queryDate);

    for (IEvent e : events) {
      // Check if query time falls within event time range [start, end)
      if (!queryTime.isBefore(e.getStart()) && queryTime.isBefore(e.getEnd())) {
        return "busy";
      }

      // Also check the original logic for backward compatibility
      if (e.getStart().equals(queryTime)) {
        return "busy";
      }
    }
    return "available";
  }

  @Override
  public Map<LocalDate, List<IEvent>> getCalendar() {
    return calendar;
  }

  @Override
  public Map<LocalDateTime, List<IEvent>> getSeries() {
    return series;
  }
}