package model.enums;

/**
 * A status enum that can only be public or private.
 */
public enum Status {
  PUBLIC, PRIVATE;
}
